from .celery import app as celery_app

__app__ = ('celery_app',)