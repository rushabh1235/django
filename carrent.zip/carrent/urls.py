from django.urls import path,include
from carrent.views import *
from .import views

urlpatterns = [
    path('oo', views.add),
    path('signup', SignupAPIView.as_view(), name='signup'),
    path('login', LoginAPIView.as_view(), name='login'),
    path('logout', UserAPIView.as_view(), name='logout'),
    path('user', UserAPIView.as_view(), name='user-put'),
    path('user', UserAPIView.as_view(), name='user-get'),
    path('car', CarAPIView.as_view(), name='car-post'),
    path('car/<int:id>', CarAPIView.as_view(), name='car-put-delete'),
    path('cardriver', CarDriverAPIView.as_view(), name='cardriver-post'),
    path('cardriver/<int:id>', CarDriverAPIView.as_view(), name='cardriver-put-delete'),
    path('booking', BookingAPIView.as_view(), name='booking-post-get'),
    
]

