from carrent.models import *
from rest_framework import serializers
from carrent.serializers import *
# class DynamicFieldsModelSerializer(serializers.ModelSerializer):
#     """
#     A ModelSerializer that takes an additional `fields` argument that
#     controls which fields should be displayed.
#     """

#     def __init__(self, *args, **kwargs):
#         # Don't pass the 'fields' arg up to the superclass
#         fields = kwargs.pop('fields', None)

#         # Instantiate the superclass normally
#         super().__init__(*args, **kwargs)

#         if fields is not None:
#             # Drop any fields that are not specified in the `fields` argument.
#             allowed = set(fields)
#             existing = set(self.fields)
#             for field_name in existing - allowed:
#                 self.fields.pop(field_name)
                
class SignupSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Signup
        fields = '__all__'
        extra_kwargs = {'password':{'write_only':True}}
        
    # def create(self, validated_data):
    #     password = validated_data.pop('password', None)
    #     instance = self.Meta.model(**validated_data)
    #     if password is not None:
    #         instance.set_password(password)
    #     instance.save()
    #     return instance
    
class LoginSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Login
        fields = '__all__'

                
class UserSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = User
        fields = '__all__'
        extra_kwargs = {'admin':{'write_only':True}, 'deleted':{'write_only':True}}

        
class CarSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Car
        fields = '__all__'
        extra_kwargs = {'deleted':{'write_only':True}}
        
class CarDriverSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Cardriver
        fields = '__all__'
        extra_kwargs = {'deleted':{'write_only':True}}

       
class BookingGetSerializer(serializers.ModelSerializer):
    users_id = UserSerializer(many=True, read_only=True)
    cars_id = CarSerializer(many=True, read_only=True)
    drivers_id = CarDriverSerializer(many=True, read_only=True)
    
    class Meta:
        model = Booking
        fields = '__all__'
        
        
class BookingSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Booking
        fields = '__all__'


        
class RatingSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Rating
        fields = '__all__'
    