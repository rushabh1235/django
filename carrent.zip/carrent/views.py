from django.shortcuts import render,HttpResponse
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from carrent.models import *
from carrent.serializers import *
from cardekho.settings import *
import datetime
from django.utils import timezone
import jwt
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import authenticate
from carrent.token import *
from django.shortcuts import get_object_or_404
# from rest_framework.permissions import IsAuthenticated
# from rest_framework.authentication import BasicAuthentication
# Create your views here.
# User APIS
# from django.core.mail import send_mail
from .tasks import add

def task(request):
    add.delay()
    return HttpResponse("done")

# def send_email(request):
    
class SignupAPIView(APIView):
    
    def post(self, request):
        try:
            json_data = request.data
            if json_data=={}:
                return Response(data={'message':'no content'}, status=status.HTTP_204_NO_CONTENT)
            
            serializer_data = SignupSerializer(data=json_data)
            if serializer_data.is_valid():
                serializer_data.save()
                return Response(data={'message':'Signup complate'}, status=status.HTTP_201_CREATED)
                # user post
                # user_serializer_data = UserSerializer(data=json_data)
                # if user_serializer_data.is_valid():
                #     user_serializer_data.save()
                    
                #     user = User.objects.filter(email=user_serializer_data.data['email']).first()
                #     print(user)
                #     refresh = RefreshToken.for_user(user)

                #     return Response({
                #         'refresh': str(refresh),
                #         'access': str(refresh.access_token),
                #     })
                # else:
                    # return Response(data={'message':user_serializer_data.errors})
            else:
                return Response(data={'message':serializer_data.errors})
        except Exception as e:
            return Response(data={'message':'Internal server error'},status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class LoginAPIView(APIView):
    

    def post(self, request):
        json_data = request.data
        try:
            if json_data == {}:
                return Response(data={'message':'no content'}, status=status.HTTP_204_NO_CONTENT)    
            model = Signup.objects.filter(email=json_data['email']).first()
            login_model = Login.objects.filter(email=json_data['email']).first()
            if model is not None:
                print("yes")
                if login_model:
                    print("login model")
                    login_password = login_model.password
                    if login_password == json_data['password']:
                        # tokens()
                        user = User.objects.filter(email=json_data['email']).first()
                        payload = {
                            'admin':user.admin,
                            'id':user.id,
                            'exp':datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
                            'iat':datetime.datetime.utcnow()
                        }
                        token = jwt.encode(payload, 'SECRET_KEY', algorithm='HS256').decode('utf-8')
                        response = Response()
                        response.set_cookie(key='jwt', value=token, httponly=True)
                        response.data={'jwt':token}
                        return response
                    else:
                        return Response(data={'message':'please cheak your password'})
                else:
                    password = model.password
                    if password == json_data['password']:
                        serializer_data = LoginSerializer(data=json_data)
                        if serializer_data.is_valid():
                            serializer_data.save()
                            # get_token()
                            user_serializer_data = UserSerializer(data=request.data)
                            if user_serializer_data.is_valid():
                                user_serializer_data.save()
                                
                                # email = user_serializer_data.data['email']
                                
                                # send_mail(
                                #     'Login_Successful',
                                #     'Congratulation your login complate successfull',
                                #     'rushabhprajapati0310@gmail.com',
                                #     '200233043032@silveroakuni.ac.in',
                                #     fail_silently=False
                                #     )
                                 
                                user = User.objects.filter(email=user_serializer_data.data['email']).first()
                                payload = {
                                            'admin':user.admin,
                                            'id':user_serializer_data.data['id'],
                                            'exp':datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
                                            'iat':datetime.datetime.utcnow()
                                        }
                                token = jwt.encode(payload, 'SECRET_KEY', algorithm='HS256').decode('utf-8')
                                response = Response()
                                response.set_cookie(key='jwt', value=token, httponly=True)
                                response.data={'jwt':token}
                                return response
                            else:
                                return Response(data={'message':serializer_data.errors})
                        else:
                            return Response(data={'message':serializer_data.errors})
                    else:
                        return Response(data={'message':'please cheak your password'})
            else:
                return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
            
            # if model is not None:
            #     password = model.password
            #     if password == json_data['password']:
            #         serializer_data = LoginSerializer(data=json_data)
            #         if serializer_data.is_valid():
            #             serializer_data.save()
            #             get_token()
            #             # user add
            #         #     user_serializer_data = UserSerializer(data=json_data)
            #         #     if user_serializer_data.is_valid():
            #         #         user_serializer_data.save()
            #         #         payload = {
            #         #             # 'admin':user_serializer_data.data['admin'],
            #         #             'id':user_serializer_data.data['id'],
            #         #             'exp':datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
            #         #             'iat':datetime.datetime.utcnow()
            #         #         }
            #         #         token = jwt.encode(payload, 'SECRET_KEY', algorithm='HS256').decode('utf-8')
            #         #         response = Response()
            #         #         response.set_cookie(key='jwt', value=token, httponly=True)
            #         #         response.data={'jwt':token}
            #         #         return response
            #         else:
            #             return Response(data={'message':serializer_data.errors})
            #     else:
            #         return Response(data={'message':'please cheak your password'})
            # else:
            #     return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        except Exception as e:
            return Response(data={'message':'internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    
            
            
class UserAPIView(APIView):

    def put(self,request):
        
        json_data=request.data
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            model = User.objects.filter(id=payload['id'], deleted=False).first()
            if model:
                serializer_data = UserSerializer(instance=model, data=json_data, partial=True)
                if serializer_data.is_valid():
                    serializer_data.save()
                else:
                    return Response(data={'message':serializer_data.errors})
                return Response(data={'message':'User updated'}, status=status.HTTP_200_OK)
            else:
                return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response(data={'message':'internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    # permission_classes = [IsAuthenticated]    
    # authentication_classes = [JWTAuthentication]  
    def get(self, request):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            model = User.objects.filter(id=payload['id'], deleted=False).first()
            if model:
                s_data = UserSerializer(model)
                return Response(data={'user':s_data.data}, status=status.HTTP_200_OK)
            else:
                return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response(data={'message':'internal servar error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
       
    def delete(self, request):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
            model = User.objects.filter(id=payload['id'], deleted=False).first()
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            if model:
                response = Response(data={'message':'Logout'})
                model.deleted = True
                response.delete_cookie('jwt')
                model.save()
                return response
            else:
                return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response(data={'message':'internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)        
                
################################# CAR RELATED APIS ###################################      
class CarAPIView(APIView):
################################# POST API ###########################################     
  
    def post(self,request):
        json_data = request.data
        json_data['available'] = "true"
        token = request.COOKIES.get('jwt')
        if token is None:
            return Response(data={'message':'unauthorized'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            if payload['admin'] == True:
                s_data = CarSerializer(data=json_data)
                if s_data.is_valid():
                    s_data.save()
                    return Response(data={'message':'Car added'}, status=status.HTTP_201_CREATED)
                else:
                    return Response(data={'message':s_data.errors})
            else:
                return Response(data={'message':'sorry only admin user access this api'})
        except Exception as e:
            return Response(data={'message':'internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)      
    
    
################################# PUT API ###########################################     
    def put(self, request, id=None):
        json_data = request.data
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthoriazed person'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            if payload['admin']==True:
                model = Car.objects.filter(id=id).first()
                if model is not None:
                    s_data = CarSerializer(instance=model, data=json_data, partial=True)
                    if s_data.is_valid():
                        s_data.save()
                        return Response(data={'message':'Car update'}, status=status.HTTP_200_OK)
                    else:
                        return Response(data={'message':s_data.errors})
        except Exception as e:
            return Response(data={'message':'internal server error'}, ststus=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
################################# GET API ###########################################     
    def get(self, request):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            models = Car.objects.all()
            if models:
                s_data = CarSerializer(models, many=True)
                return Response(data={'message':s_data.data}, status=status.HTTP_200_OK)
            else:
                return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response(data={'message':'internal servar error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


################################# DELETE API ###########################################     
    def delete(self, request,id=None):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            if payload['admin'] == True:
                model = Car.objects.filter(id=id, deleted=False).first()
                if model:
                    model.deleted = True
                    model.save()
                    return Response(data={'user':'no content'}, status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response(data={'message':'sorry only admin user access this api'})
        except Exception as e:
            return Response(data={'message':'internal servar error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


################################# CARDRIVER RELATED APIS #############################
class CarDriverAPIView(APIView):
################################# POST API ###########################################     

    def post(self,request):
        json_data = request.data
        json_data['available']="true"
        token = request.COOKIES.get('jwt')
        if token is None:
            return Response(data={'message':'unauthorized'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            if payload['admin'] == True:
                s_data = CarDriverSerializer(data=json_data)
                if s_data.is_valid():
                    s_data.save()
                    return Response(data={'message':'CarDriver added'}, status=status.HTTP_201_CREATED)
                else:
                    return Response(data={'message':s_data.errors})
            else:
                return Response(data={'message':'sorry only admin user access this api'})
        except Exception as e:
            return Response(data={'message':'internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)      
                

################################# PUT API ###########################################     
    def put(self, request, id=None):
        json_data = request.data
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthoriazed person'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            if payload['admin']==True:  
                model = Cardriver.objects.filter(id=id, deleted=False).first()
                if model is not None:
                    s_data = CarDriverSerializer(instance=model, data=json_data, partial=True)
                    if s_data.is_valid():
                        s_data.save()
                        return Response(data={'message':'CarDriver profile update'}, status=status.HTTP_200_OK)
                    else:
                        return Response(data={'message':s_data.errors})
        except Exception as e:
            return Response(data={'message':'internal server error'}, ststus=status.HTTP_500_INTERNAL_SERVER_ERROR)

               
################################# GET API ###########################################     
    def get(self, request):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            models = Cardriver.objects.filter(deleted=False).order_by('-year_of_experience')
            if models:
                s_data = CarDriverSerializer(models, many=True)
                return Response(data={'message':s_data.data}, status=status.HTTP_200_OK)
            else:
                return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response(data={'message':'internal servar error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


################################# DELETE API ###########################################     
    def delete(self, request,id=None):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            if payload['admin'] == True:
                model = Cardriver.objects.filter(id=id, deleted=False).first()
                if model:
                    model.deleted = True
                    model.save()
                    return Response(data={'user':'no content'}, status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response(data={'message':'sorry only admin user access this api'})
        except Exception as e:
            return Response(data={'message':'internal servar error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


################################# BOOKING RELATED APIS #############################
class BookingAPIView(APIView):
################################# POST API ###########################################     

    def post(self,request):
        json_data = request.data
        token = request.COOKIES.get('jwt')
        if token is None:
            return Response(data={'message':'unauthorized'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:    
            car = get_object_or_404(Car, id=json_data['car_id'])
            driver = get_object_or_404(Cardriver, id=json_data['driver_id'])
            pick_date = json_data['pickup_date']
            drope_date = json_data['return_date']
            # print(pick_date)
            # d = datetime.datetime.utcnow()
            # current_date = d.strftime("%Y-%m-%d %H:%M:%S")
            # if pick_date__lte = current_date or drope_date_lte = current_date:
            #     return Response(date={'message':'only future or current booking available not past booking'})
           
            # cheak this time duration car available or not
            booking_car_data = Booking.objects.filter(car_id=json_data['car_id'], pickup_date__lte=drope_date, 
                                                 return_date__gte=pick_date).first()
            if booking_car_data:
                return Response(data={'message':'This time duration this perticular CAR not available please choose another car'})
            
            # cheak this time duration driver available or not
            booking_driver_data = Booking.objects.filter(driver_id=json_data['driver_id'], pickup_date__lte=drope_date, 
                                                 return_date__gte=pick_date).first()
            if booking_driver_data:
                return Response(data={'message':'This time duration this perticular driver not available please choose another driver'.format(json_data['driver_id'])})
            
            # payment detailes
            if json_data['rent_type'] == 'per_houre' or json_data['rent_type'] == 'PER_HOURE':
                json_data['total_cost'] = car.hourly_rate*json_data['rental_duration']
            else:
                json_data['total_cost'] = car.daily_rate*json_data['rental_duration']
                
            s_data = BookingSerializer(data=json_data)
            if s_data.is_valid():
                s_data.save()
                car.available=False
                car.save()
                driver.available=False
                driver.save()
                return Response(data={'message':'redirect payment page'})
            else:
                return Response(data={'message':s_data.errors})
        except Exception as e:
            return Response(data={'message':'internal server error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)      

                
################################# GET API ###########################################     
    
    def get(self, request):
        
        token = request.COOKIES.get('jwt')
        if not token:
            return Response(data={'message':'unauthorized person'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            payload = jwt.decode(token, 'SECRET_KEY', algorithm=['HS256'])
        except jwt.ExpiredSignatureError:
            return Response(data={'message':'your token has been expired'}, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            models = Booking.objects.filter(user_id=payload['id']).first()
            if models:
                s_data = BookingGetSerializer(models)
                return Response(data={'message':s_data.data}, status=status.HTTP_200_OK)
            else:
                return Response(data={'message':'model not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response(data={'message':'internal servar error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

