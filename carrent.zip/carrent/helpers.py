# fevourite driver choice
FEVOURITE_DRIVERS_NAMES = [
    ('manoj', 'MANOJ'),('sandip', 'SANDIP'),('ravi', 'RAVI'),
    ('rushabh','RUSHABH'), ('jass','JASS'), ('monali','MONALI'),
    ('dhruv','DHRUV'), ('pratik','PRATIK'), ('jasmin','JASMIN'),
    ('sandy','SANDY'), ('roy','ROY'), ('rohan','ROHAN')]

# FEVOURITE_DRIVERS = [(i,i) for i in FEVOURITE_DRIVERS_NAMES]


# # type of rent
# TYPE_OF_RENTS = [('per_houre', 'PER_HOURE'),
#             ('per_day', 'PER_DAY')]

# RENT_TYPE = [(i,i) for i in TYPE_OF_RENTS]


# # driver choice type
# CHOICE_TYPE = [('yes','YES'), ('no', 'NO')]

# DRIVER_CHOICE = [(i,i) for i in CHOICE_TYPE]