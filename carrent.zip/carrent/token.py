from carrent.serializers import *
def tokens():
    user_serializer_data = UserSerializer(data=request.data)
    if user_serializer_data.is_valid():
        user_serializer_data.save()
        payload = {
                    # 'admin':user_serializer_data.data['admin'],
                    'id':user_serializer_data.data['id'],
                    'exp':datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
                    'iat':datetime.datetime.utcnow()
                }
        token = jwt.encode(payload, 'SECRET_KEY', algorithm='HS256').decode('utf-8')
        response = Response()
        response.set_cookie(key='jwt', value=token, httponly=True)
        response.data={'jwt':token}
        return response
    else:
        return Response(data={'message':serializer_data.errors})