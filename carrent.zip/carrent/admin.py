from django.contrib import admin

# Register your models here.
from carrent.models import *

admin.site.register(Car)
admin.site.register(Booking)
admin.site.register(User)
admin.site.register(Cardriver)
admin.site.register(Rating)
admin.site.register(Signup)
admin.site.register(Login)