from django.db import models
from carrent.helpers import FEVOURITE_DRIVERS_NAMES as FD
from decimal import Decimal
from rest_framework.response import Response
from django.core.exceptions import ValidationError
from rest_framework import serializers
# from carrent.helpers import RENT_TYPE as RT
# from carrent.helpers import DRIVER_CHOICE as DC
# Create your models here.

class User(models.Model):
    
    class Meta:
        db_table = "user"
        
    first_name = models.CharField(max_length=60, null=True)
    last_name = models.CharField(max_length=60, null=True)
    full_name = models.CharField(max_length=260, null=True)
    email = models.EmailField(max_length=254)
    country_code = models.CharField(max_length=10, null=True)
    mobile_no = models.IntegerField(null=True)
    deleted = models.BooleanField(default=False, null=True)
    admin = models.BooleanField(default=False, null=True)
    
    def __repr__(self):
        return 'User id:{}'.formate(self.id)


class Signup(models.Model):
    
    class Meta:
        db_table = 'signup'
    
    first_name = models.CharField(max_length=60)
    last_name = models.CharField(max_length=60)
    email = models.EmailField(max_length=254, unique=True)
    password = models.CharField(max_length=60)
    
    def __repr__(self):
        return 'Signup id:{}'.formate(self.id)
     
class Login(models.Model):
    
    class Meta:
        db_table = 'login'
        
    email = models.EmailField(max_length=254)
    password = models.CharField(max_length=60)
    # forgetpassword
    
    def __repr__(self):
        return 'Login id:{}'.formate(self.id) 


    
class Car(models.Model):
    
    class Meta:
        db_table = "car"
        
    car_image = models.ImageField(blank=True,null=True)
    car_name = models.CharField(max_length=60)
    car_information = models.CharField(max_length=120)
    number_plate = models.CharField(max_length=100)
    hourly_rate = models.DecimalField(max_digits=8, decimal_places=2) 
    daily_rate = models.DecimalField(max_digits=8, decimal_places=2)
    deleted = models.BooleanField(default=False)
    available = models.BooleanField(default=True)
    # when driver click button his goes to booking page   

    def __repr__(self):
        return 'Car id:{}'.formate(self.id)


class Cardriver(models.Model):
    
    class Meta:
        db_table = 'cardriver'
        
    image = models.ImageField(blank=True,null=True)
    first_name = models.CharField(max_length=60)
    last_name = models.CharField(max_length=60)
    mobile_no = models.IntegerField()
    year_of_experience = models.IntegerField()
    available = models.BooleanField(default=True, null=True)
    deleted = models.BooleanField(default=False) 

    def __repr__(self):
        return 'Cardriver id:{}'.formate(self.id)
     
class Booking(models.Model):
    
    class Meta:
        db_table = "booking"
        
    user_id = models.ForeignKey(User, related_name="users_id", on_delete=models.CASCADE)
    car_id = models.ForeignKey(Car, related_name="cars_id", on_delete=models.CASCADE)
    pickup_date = models.DateTimeField()
    return_date = models.DateTimeField()
    rent_type = models.CharField(max_length=20, choices=[('per_houre', 'PER_HOURE'),
            ('per_day', 'PER_DAY')])
    rental_duration = models.PositiveIntegerField()
    driver_choice = models.CharField(max_length=50, choices=[('yes','YES'), ('no', 'NO')])
    driver_id = models.ForeignKey(Cardriver, related_name="drivers_id", on_delete=models.SET_NULL,
                               blank=True, null=True, choices=FD)
    total_cost = models.DecimalField(max_digits=20, decimal_places=4,null=True, default=Decimal('0.0000'))
    # if user choose yes driver field unhide other wise not
    # user alse see driver information
    # when user push book button user goes to payment page (pending this model)   
    # when booking comform user get one notification your booking successfull

    def __repr__(self):
        return 'User id:{} Booking successfull'.formate(self.user)
    
class Rating(models.Model):
    
    class Meta:
        db_table = 'rating'
        
    user_id = models.ForeignKey(User, related_name="user_id", on_delete=models.CASCADE)
    driver_id = models.ForeignKey(Cardriver, related_name="driver_id", on_delete=models.CASCADE)
    rating = models.PositiveIntegerField(choices=[(i,i) for i in range(1,6)])
    commant = models.CharField(max_length=120)
    
    def __repr__(self):
        return 'Rating id:{}'.formate(self.id)